# MAproductions Website

This is the official website for MAproductions, built with Bootstrap 5.

## How to Host on GitHub Pages

1. Create a new public repository on GitHub (e.g., MAproductions-site).
2. Upload all files and folders from this zip into that repository.
3. Commit the changes.
4. Go to **Settings → Pages**, set the source to **main branch / root**, and save.
5. Your site will be live at:
   `https://yourusername.github.io/MAproductions-site`

© 2025 MAproductions | TAMS Merch by TAMS Students
